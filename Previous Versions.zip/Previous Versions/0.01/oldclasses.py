from resource import *

class Mass(pygame.sprite.Sprite):
    def __init__(self, mass=1, angle=0, x=0, y=0, dx=0, dy=0, imageName='mass.png'):
        pygame.sprite.Sprite.__init__(self)
        self.dx = dx; self.dy = dy #Velocity
        self.mass = mass; self.angle = angle #Mass, orientation
        self.image, self.rect = image(imageName) #Image, bounding box
        self.rect.left = x; self.rect.top = y
    def update(self, time):
        self.rect.move_ip(self.dx*time, self.dy*time)
    def draw(self, screen, offset=(0,0)):
        rotatedImage = pygame.transform.rotozoom(self.image, self.angle, 1)
        screen.blit(rotatedImage, (self.rect.left+offset[0], self.rect.top+offset[1]) )
        
class Ship(Mass):
    def __init__(self):
        Mass.__init__(self)
        self.mass = self.rect.width**1.5 * self.rect.height**1.5 * 100
    def update(self, time):
        Mass.update(self, time)

class Player():
    def __init__(self, type):
        self.money = 0
        self.energy = 0
        self.ore = 0
        self.type = type
        self.ships = []

s = Ship()
s.update(33)
