import sys
import random
import math
import os
import pygame
import socket
from pygame.locals import *

loaded_images = dict()

def image(name):
    """ Load image and return image object"""
    if name in loaded_images:
        return loaded_images[name]
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
        if image.get_alpha() is None:
            image = image.convert()
        else:
            image = image.convert_alpha()
    except pygame.error, message:
        print 'Cannot load image:', fullname
        raise SystemExit, message
    loaded_images[name] = image, image.get_rect()
    return loaded_images[name]

def sound(name):
    class NoneSound:
        def play(self): pass
    if not pygame.mixer:
        return NoneSound()
    fullname = os.path.join('data', name)
    try:
        sound = pygame.mixer.Sound(fullname)
    except pygame.error, message:
        print 'Cannot load sound:', fullname
        raise SystemExit, message
    return sound

def error_log(s): open('error_log.txt',"a").write(s+'\n')

os.chdir(sys.argv[0][0:sys.argv[0].rfind("\\")]) #Ensure right folder
pygame.init()
screen = pygame.display.set_mode((600, 500))
screenSize = screen.get_size()
pygame.display.set_caption('Peace')
pygame.mouse.set_cursor(*pygame.cursors.broken_x)

font = pygame.font.Font("data/font.ttf", 100)
