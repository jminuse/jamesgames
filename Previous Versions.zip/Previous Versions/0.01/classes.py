from resource import *

class Mass():
    def __init__(self, world, mass=1, angle=0, x=500, y=500, dx=0, dy=0, angle_velocity = 0, imageName='mass.png', poly=None):
        self.dx = dx; self.dy = dy #Velocity
        self.mass = mass; self.world = world #Mass, world
        self.original_image, self.rect = image(imageName) #Image, bounding box
        self.x = x; self.y = y
        if poly is None:
            poly = ( (-self.rect.centerx, self.rect.centery), (-self.rect.centerx, -self.rect.centery),
                (self.rect.centerx, -self.rect.centery), (self.rect.centerx, self.rect.centery) )
        self.rotations = [ [ (math.cos(a)*p[0]-math.sin(a)*p[1], math.sin(a)*p[0]+math.cos(a)*p[1]) for p in poly] for a in range(100) ]
        self.angle = 0; self.rotate(angle)
        self.angle_velocity = angle_velocity
    def update(self, time):
        self.x += self.dx*time; self.y += self.dy*time; self.rotate(self.angle_velocity*time)
        if self.x > self.world.w: self.x = self.world.w; self.dx *= -1
        elif self.x < 0: self.x = 0; self.dx *= -1
        if self.y > self.world.h: self.y = self.world.h; self.dy *= -1
        elif self.y < 0: self.y = 0; self.dy *= -1
    def rotate(self, angle):
        self.angle += angle
        while self.angle<0: self.angle+=2*math.pi
        while self.angle>2*math.pi: self.angle-=2*math.pi
        self.poly = self.rotations[ int(len(self.rotations)*self.angle/(2*math.pi)) ]
        self.image = pygame.transform.rotozoom(self.original_image, math.degrees(self.angle), 1).convert_alpha()
        self.rect = self.image.get_rect()
    def display(self, screen, offset=(0,0)):
        screen.blit(self.image, (self.x-self.rect.centerx-offset[0], self.y-self.rect.centery-offset[1]) )
    def contacts(self, x, y):
        j = len(self.poly)-1; within = False
        for i in range(len(self.poly)):
            within ^= ( ((self.poly[i][1]>y) != (self.poly[j][1]>y)) and (x < (self.poly[j][0]-self.poly[i][0])
                * (y-self.poly[i][1]) / (self.poly[j][1]-self.poly[i][1]) + self.poly[i][0]) ); j = i
        return within
    def collides(self,other):
        return False
        
class Ship(Mass):
    def __init__(self, world):
        Mass.__init__(self, world, imageName='ship.png')
        self.thrust = 0
        self.maxThrust = 1
    def update(self, time):
        Mass.update(self, time)

class Planetoid(Mass):
    def __init__(self):
        Mass.__init__(self)
    def update(self, time):
        Mass.update(self, time)

class Player():
    def __init__(self, type):
        self.money = 0
        self.energy = 0
        self.ore = 0
        self.type = type
        self.ships = []

class World():
    def __init__(self, w=1000, h=1000):
        self.w = w; self.h = h
        self.ships = []; self.planetoids = []; self.players = []
        for i in range(50):
            self.ships.append(Ship(self))
            self.ships[-1].dx = math.sin(i)/10
            self.ships[-1].dy = math.cos(i)/10
            self.ships[-1].angle_velocity = 0.001
    def update(self, time):
        for ship in self.ships:
	    ship.update(time)
    def display(self, screen, screenSize, background, offset):
        screen.blit(background, (0,0), (offset[0],offset[1],screenSize[0],screenSize[1]) )
        for ship in self.ships: ship.display(screen, offset)
	pygame.display.flip()
        